# Hour 4: Advanced CSS & Responsive Design
## Guided Coding Exercises

### Exercise 4.1: CSS Custom Properties (Variables) (20 minutes)

**Objective:** Learn to use CSS variables for maintainable, themeable code.

**Step 1:** Define your color palette
\`\`\`css
:root {
    /* Color palette */
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --accent-color: #f093fb;
    
    /* Grayscale */
    --gray-50: #f7fafc;
    --gray-100: #edf2f7;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e0;
    --gray-600: #718096;
    --gray-700: #4a5568;
    --gray-800: #2d3748;
    --gray-900: #1a202c;
    
    /* Spacing */
    --space-xs: 0.5rem;
    --space-sm: 1rem;
    --space-md: 1.5rem;
    --space-lg: 2rem;
    --space-xl: 3rem;
    --space-2xl: 4rem;
    
    /* Typography */
    --font-size-sm: 0.875rem;
    --font-size-base: 1rem;
    --font-size-lg: 1.125rem;
    --font-size-xl: 1.25rem;
    --font-size-2xl: 1.5rem;
    --font-size-3xl: 2rem;
    
    /* Shadows */
    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.05), 0 10px 25px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 8px 25px rgba(0, 0, 0, 0.1), 0 20px 40px rgba(0, 0, 0, 0.15);
}
\`\`\`

**What you learned:**
- `:root` defines global CSS variables
- `--variable-name` syntax for custom properties
- Organize variables by category (colors, spacing, etc.)

**Step 2:** Use variables in your components
\`\`\`css
.header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    padding: var(--space-2xl) 0;
    text-align: center;
}

.header__title {
    font-size: clamp(var(--font-size-3xl), 5vw, 4rem);
    font-weight: 700;
    margin-bottom: var(--space-sm);
    letter-spacing: -0.02em;
}

.card {
    background: white;
    border-radius: 12px;
    box-shadow: var(--shadow-md);
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.card:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-lg);
}
\`\`\`

**What you learned:**
- `var(--variable-name)` uses the variable value
- Easy to maintain consistent spacing and colors
- Change one variable to update the entire theme

**Step 3:** Create a dark theme
\`\`\`css
/* Dark theme variables */
[data-theme="dark"] {
    --gray-50: #1a202c;
    --gray-100: #2d3748;
    --gray-200: #4a5568;
    --gray-300: #718096;
    --gray-600: #cbd5e0;
    --gray-700: #e2e8f0;
    --gray-800: #edf2f7;
    --gray-900: #f7fafc;
}

/* Update body to use variables */
body {
    background-color: var(--gray-50);
    color: var(--gray-800);
}

.card {
    background: var(--gray-100);
    color: var(--gray-800);
}
\`\`\`

**Test it:** Add `data-theme="dark"` to your `<html>` tag to see the dark theme!

### Exercise 4.2: Advanced Animations and Transitions (25 minutes)

**Step 1:** Create smooth hover effects
\`\`\`css
.card {
    background: white;
    border-radius: 12px;
    box-shadow: var(--shadow-md);
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
}

.card:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-lg);
}

.card__image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.card:hover .card__image {
    transform: scale(1.05);
}
\`\`\`

**What you learned:**
- `cubic-bezier()` creates custom easing curves
- `transform` is more performant than changing `top/left`
- Layer multiple transitions for complex effects

**Step 2:** Add loading animations
\`\`\`css
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes pulse {
    0%, 100% {
        opacity: 1;
    }
    50% {
        opacity: 0.5;
    }
}

.card {
    animation: fadeInUp 0.6s ease forwards;
}

/* Stagger the animations */
.card:nth-child(1) { animation-delay: 0.1s; }
.card:nth-child(2) { animation-delay: 0.2s; }
.card:nth-child(3) { animation-delay: 0.3s; }
.card:nth-child(4) { animation-delay: 0.4s; }
.card:nth-child(5) { animation-delay: 0.5s; }
.card:nth-child(6) { animation-delay: 0.6s; }

/* Loading state */
.card--loading {
    animation: pulse 2s infinite;
}
\`\`\`

**What you learned:**
- `@keyframes` define custom animations
- `animation-delay` creates staggered effects
- `forwards` keeps the final animation state

**Step 3:** Add button micro-interactions
\`\`\`css
.btn {
    display: inline-flex;
    align-items: center;
    gap: var(--space-xs);
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 8px;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
    position: relative;
    overflow: hidden;
}

.btn--primary {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
}

.btn--primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn--primary:active {
    transform: translateY(0);
    transition-duration: 0.1s;
}

.btn__icon {
    width: 1rem;
    height: 1rem;
    transition: transform 0.2s ease;
}

.btn:hover .btn__icon {
    transform: translateX(2px);
}

/* Ripple effect */
.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.3s, height 0.3s;
}

.btn:active::before {
    width: 300px;
    height: 300px;
}
\`\`\`

**What you learned:**
- Micro-interactions improve user experience
- `::before` pseudo-element creates effects without extra HTML
- Different transition durations for different states

### Exercise 4.3: Responsive Design Patterns (20 minutes)

**Step 1:** Mobile-first approach
\`\`\`css
/* Mobile styles first (default) */
.container {
    max-width: 100%;
    margin: 0 auto;
    padding: 0 var(--space-sm);
}

.portfolio__grid {
    display: grid;
    grid-template-columns: 1fr; /* Single column on mobile */
    gap: var(--space-md);
}

.header {
    padding: var(--space-xl) 0;
}

.header__title {
    font-size: var(--font-size-3xl);
}

/* Tablet styles */
@media (min-width: 768px) {
    .container {
        padding: 0 var(--space-md);
    }
    
    .portfolio__grid {
        grid-template-columns: repeat(2, 1fr); /* Two columns */
        gap: var(--space-lg);
    }
    
    .header {
        padding: var(--space-2xl) 0;
    }
}

/* Desktop styles */
@media (min-width: 1024px) {
    .container {
        max-width: 1200px;
        padding: 0 var(--space-lg);
    }
    
    .portfolio__grid {
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: var(--space-lg);
    }
}

/* Large desktop */
@media (min-width: 1440px) {
    .container {
        max-width: 1400px;
    }
}
\`\`\`

**What you learned:**
- Mobile-first is easier to maintain
- Progressive enhancement adds features for larger screens
- Use consistent breakpoints across your project

**Step 2:** Responsive typography
\`\`\`css
.header__title {
    font-size: clamp(2rem, 5vw, 4rem);
    line-height: 1.2;
}

.header__description {
    font-size: clamp(1rem, 2.5vw, 1.25rem);
    line-height: 1.6;
}

.card__title {
    font-size: clamp(1.25rem, 3vw, 1.5rem);
}

/* Responsive spacing */
.header {
    padding: clamp(2rem, 8vw, 4rem) 0;
}

.main {
    padding: clamp(2rem, 6vw, 4rem) 0;
}
\`\`\`

**What you learned:**
- `clamp(min, preferred, max)` creates fluid typography
- `vw` units scale with viewport width
- Reduces need for media queries

### Exercise 4.4: Advanced Layout Techniques (15 minutes)

**Step 1:** Create a sticky header
\`\`\`css
.header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    backdrop-filter: blur(10px);
}

/* Add a subtle shadow when scrolled */
.header--scrolled {
    box-shadow: var(--shadow-md);
}
\`\`\`

**Step 2:** Implement container queries (modern browsers)
\`\`\`css
.card {
    container-type: inline-size;
}

/* When card is wider than 400px, change layout */
@container (min-width: 400px) {
    .card__content {
        padding: var(--space-lg);
    }
    
    .card__title {
        font-size: var(--font-size-xl);
    }
}
\`\`\`

**What you learned:**
- Container queries respond to element size, not viewport
- More precise control than media queries
- Perfect for component-based design

### Hour 4 Challenge: Create a Theme Switcher

**Your Task:** Create a theme switcher that toggles between light and dark modes.

**HTML:**
\`\`\`html
<button class="theme-toggle" id="theme-toggle" aria-label="Toggle theme">
    <svg class="theme-toggle__icon theme-toggle__icon--sun" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
    </svg>
    <svg class="theme-toggle__icon theme-toggle__icon--moon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
    </svg>
</button>
\`\`\`

**CSS:**
\`\`\`css
.theme-toggle {
    position: fixed;
    top: var(--space-lg);
    right: var(--space-lg);
    width: 3rem;
    height: 3rem;
    border: none;
    border-radius: 50%;
    background: var(--gray-100);
    color: var(--gray-700);
    cursor: pointer;
    transition: all 0.3s ease;
    z-index: 1000;
}

.theme-toggle:hover {
    background: var(--gray-200);
    transform: scale(1.1);
}

.theme-toggle__icon {
    width: 1.25rem;
    height: 1.25rem;
    transition: all 0.3s ease;
}

.theme-toggle__icon--moon {
    display: none;
}

[data-theme="dark"] .theme-toggle__icon--sun {
    display: none;
}

[data-theme="dark"] .theme-toggle__icon--moon {
    display: block;
}
\`\`\`

**JavaScript (preview for next hour):**
\`\`\`javascript
function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
}

document.getElementById('theme-toggle').addEventListener('click', toggleTheme);
\`\`\`

### Accessibility Considerations

**1. Respect user preferences:**
\`\`\`css
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
}

@media (prefers-color-scheme: dark) {
    :root {
        /* Automatically use dark theme if user prefers it */
    }
}
\`\`\`

**2. High contrast support:**
\`\`\`css
@media (prefers-contrast: high) {
    .card {
        border: 2px solid var(--gray-800);
    }
    
    .btn--primary {
        background: var(--gray-900);
        color: white;
    }
}
\`\`\`

### Key Takeaways from Hour 4:
- ✅ CSS variables make themes and maintenance easier
- ✅ Mobile-first responsive design is more maintainable
- ✅ `clamp()` creates fluid, responsive designs
- ✅ Micro-interactions improve user experience
- ✅ Always consider accessibility and user preferences
- ✅ Modern CSS features reduce JavaScript dependencies
