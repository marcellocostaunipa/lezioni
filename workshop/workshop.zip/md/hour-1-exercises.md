# Hour 1: HTML5 Foundations & Semantic Structure
## Guided Coding Exercises

### Exercise 1.1: Setting Up the Basic HTML Structure (15 minutes)

**Objective:** Create a proper HTML5 document with semantic structure.

**Step 1:** Create the basic HTML5 document
\`\`\`html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Creative Portfolio</title>
</head>
<body>
    <!-- We'll add content here -->
</body>
</html>
\`\`\`

**What you learned:**
- `<!DOCTYPE html>` tells the browser this is HTML5
- `lang="en"` helps screen readers and search engines
- `viewport` meta tag makes the site mobile-friendly

**Step 2:** Add the semantic header structure
\`\`\`html
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header__title">Creative Coding Portfolio</h1>
            <p class="header__description">
                Welcome to my collection of interactive sketches.
            </p>
        </div>
    </header>
</body>
\`\`\`

**What you learned:**
- `<header>` is semantic - it tells browsers and screen readers this is the page header
- Class names use BEM methodology: `block__element`
- `<h1>` should be used only once per page for the main title

### Exercise 1.2: Creating the Main Content Structure (20 minutes)

**Step 1:** Add the main content area
\`\`\`html
<!-- Add this after the header -->
<main class="main">
    <div class="container">
        <section class="portfolio">
            <h2 class="portfolio__title">My Sketches</h2>
            <div class="portfolio__grid">
                <!-- Cards will go here -->
            </div>
        </section>
    </div>
</main>
\`\`\`

**What you learned:**
- `<main>` contains the primary content of the page
- `<section>` groups related content together
- `<h2>` creates a proper heading hierarchy

**Step 2:** Create your first portfolio card
\`\`\`html
<!-- Add this inside portfolio__grid -->
<article class="card">
    <div class="card__preview">
        <img src="/placeholder.svg?height=200&width=300" 
             alt="Colorful particle animation" 
             class="card__image">
        <div class="card__overlay">
            <svg class="card__play-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <polygon points="5,3 19,12 5,21"></polygon>
            </svg>
        </div>
    </div>
    <div class="card__content">
        <h3 class="card__title">Particle System</h3>
        <p class="card__description">Interactive particles that respond to mouse movement</p>
        <button class="btn btn--primary" data-sketch="particle-system">
            View Sketch
        </button>
    </div>
</article>
\`\`\`

**What you learned:**
- `<article>` represents standalone content
- `alt` text describes images for screen readers
- `data-*` attributes store custom data for JavaScript

### Exercise 1.3: Adding the Modal Dialog (15 minutes)

**Step 1:** Add the new HTML5 dialog element
\`\`\`html
<!-- Add this before the closing </body> tag -->
<dialog class="modal" id="sketch-modal">
    <div class="modal__content">
        <header class="modal__header">
            <h2 class="modal__title" id="modal-title">Sketch Title</h2>
            <button class="modal__close" id="close-modal" aria-label="Close modal">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </header>
        <div class="modal__body">
            <div class="modal__sketch-container" id="sketch-container">
                <!-- p5.js sketch will appear here -->
            </div>
        </div>
    </div>
</dialog>
\`\`\`

**What you learned:**
- `<dialog>` is a new HTML5 element for modals
- `aria-label` provides accessible button descriptions
- `id` attributes allow JavaScript to find elements

### Exercise 1.4: Accessibility Improvements (10 minutes)

**Step 1:** Add skip navigation for keyboard users
\`\`\`html
<!-- Add this right after <body> -->
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- Update your main element -->
<main class="main" id="main-content">
\`\`\`

**Step 2:** Improve button accessibility
\`\`\`html
<!-- Update your card button -->
<button class="btn btn--primary" 
        data-sketch="particle-system"
        aria-describedby="particle-desc">
    View Sketch
    <span class="sr-only">- Particle System</span>
</button>
\`\`\`

**What you learned:**
- Skip links help keyboard users navigate quickly
- `aria-describedby` connects elements for screen readers
- `sr-only` class hides content visually but keeps it for screen readers

### Hour 1 Challenge: Create Your Second Card

**Your Task:** Create another portfolio card for a "Fractal Tree" sketch. Use the same structure but change:
- Image alt text
- Card title and description
- Button data-sketch attribute

**Solution:**
\`\`\`html
<article class="card">
    <div class="card__preview">
        <img src="/placeholder.svg?height=200&width=300" 
             alt="Branching fractal tree pattern" 
             class="card__image">
        <div class="card__overlay">
            <svg class="card__play-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <polygon points="5,3 19,12 5,21"></polygon>
            </svg>
        </div>
    </div>
    <div class="card__content">
        <h3 class="card__title">Fractal Tree</h3>
        <p class="card__description">Recursive tree that grows and changes over time</p>
        <button class="btn btn--primary" data-sketch="fractal-tree">
            View Sketch
        </button>
    </div>
</article>
\`\`\`

### Key Takeaways from Hour 1:
- ✅ Semantic HTML improves accessibility and SEO
- ✅ Proper heading hierarchy (h1 → h2 → h3) helps navigation
- ✅ Alt text and ARIA labels make content accessible
- ✅ The `<dialog>` element provides native modal functionality
- ✅ BEM class naming keeps CSS organized
