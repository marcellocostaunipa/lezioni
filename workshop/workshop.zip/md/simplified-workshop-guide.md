# 8-Hour Web Standards Workshop: Building a p5.js Portfolio (Simplified JavaScript)

## Workshop Overview
This workshop teaches modern web standards through building a portfolio website for p5.js creative coding projects. Students will learn HTML5, CSS3, and JavaScript fundamentals using function-based programming instead of complex class structures.

## Learning Objectives
By the end of this workshop, participants will:
- Understand semantic HTML5 structure and accessibility
- Master CSS Grid and Flexbox for modern layouts
- Write clean, function-based JavaScript
- Use the new HTML `<dialog>` element
- Integrate p5.js sketches into web applications
- Apply responsive design principles

## Workshop Schedule (8 Hours)

### Hour 1: HTML5 Foundations & Semantic Structure
**Topics Covered:**
- Modern HTML5 document structure
- Semantic elements (`<header>`, `<main>`, `<article>`, `<section>`)
- Accessibility best practices (ARIA, alt text, semantic markup)
- The new `<dialog>` element
- Meta tags and viewport configuration

**Key Learning Points:**
- Use semantic HTML for better accessibility and SEO
- The `<dialog>` element provides native modal functionality
- Proper document structure improves code maintainability

**Hands-on Activity:**
Build the basic HTML structure for the portfolio with semantic markup.

### Hour 2: CSS Grid Mastery
**Topics Covered:**
- CSS Grid fundamentals
- `grid-template-columns` with `repeat()` and `minmax()`
- Responsive grid layouts with `auto-fit`
- Grid gap and alignment properties

**Key Code Example:**
\`\`\`css
.portfolio__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}
\`\`\`

**Learning Focus:**
- CSS Grid is perfect for two-dimensional layouts
- `auto-fit` creates responsive grids without media queries
- `minmax()` ensures cards have minimum and maximum sizes

### Hour 3: CSS Flexbox for Components
**Topics Covered:**
- Flexbox fundamentals for one-dimensional layouts
- `flex-direction`, `align-items`, `justify-content`
- Building flexible button and card components
- Combining Flexbox with Grid

**Key Code Example:**
\`\`\`css
.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.card__content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
\`\`\`

**Learning Focus:**
- Flexbox excels at component-level layouts
- Use Flexbox inside Grid items for complete layout control
- `gap` property works with both Grid and Flexbox

### Hour 4: Advanced CSS & Responsive Design
**Topics Covered:**
- CSS custom properties (variables)
- Transitions and hover effects
- Media queries for responsive design
- CSS architecture with BEM methodology

**Key Code Example:**
\`\`\`css
:root {
  --primary-color: #667eea;
  --secondary-color: #764ba2;
}

.card:hover {
  transform: translateY(-8px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
}
\`\`\`

**Learning Focus:**
- CSS custom properties make themes and maintenance easier
- Smooth transitions enhance user experience
- Mobile-first responsive design is the modern standard

### Hour 5: JavaScript Fundamentals (Function-Based)
**Topics Covered:**
- Variables and function declarations
- DOM selection with `querySelector` and `querySelectorAll`
- Event listeners and event handling
- Function organization and scope

**Key Code Example:**
\`\`\`javascript
// Global variables for important elements
let modal = null;
let currentSketch = null;

// Initialize the application
function initializeApp() {
  modal = document.getElementById('sketch-modal');
  setupEventListeners();
}

// Handle button clicks
function handleSketchButtonClick(event) {
  const sketchId = event.currentTarget.getAttribute('data-sketch');
  openModal(sketchId);
}
\`\`\`

**Learning Focus:**
- Functions are the building blocks of JavaScript
- Global variables store application state
- Event listeners connect user actions to JavaScript functions

### Hour 6: Modal Functionality & DOM Manipulation
**Topics Covered:**
- Working with the HTML `<dialog>` element
- Dynamic content insertion
- Managing application state
- Keyboard navigation and accessibility

**Key Code Example:**
\`\`\`javascript
function openModal(sketchId, title) {
  modalTitle.textContent = title;
  loadSketch(sketchId);
  modal.showModal();
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modal.close();
  cleanupSketch();
  document.body.style.overflow = '';
}
\`\`\`

**Learning Focus:**
- The `showModal()` method provides native modal behavior
- Always clean up resources when closing modals
- Prevent body scroll when modal is open

### Hour 7: p5.js Integration
**Topics Covered:**
- p5.js instance mode for multiple sketches
- Creating sketch factory functions
- Canvas management and responsive sizing
- Sketch lifecycle management

**Key Code Example:**
\`\`\`javascript
function createParticleSystemSketch() {
  return function(p) {
    let particles = [];

    p.setup = function() {
      const canvas = p.createCanvas(800, 600);
      canvas.parent(sketchContainer);
      
      // Initialize particles
      for (let i = 0; i < 100; i++) {
        particles.push({
          x: p.random(p.width),
          y: p.random(p.height),
          vx: p.random(-2, 2),
          vy: p.random(-2, 2)
        });
      }
    };

    p.draw = function() {
      p.background(20, 25, 40);
      // Update and draw particles
    };
  };
}
\`\`\`

**Learning Focus:**
- Instance mode prevents conflicts between multiple sketches
- Factory functions create reusable sketch templates
- Always clean up p5 instances to prevent memory leaks

### Hour 8: Performance & Accessibility
**Topics Covered:**
- Intersection Observer for scroll animations
- Keyboard navigation implementation
- Performance monitoring basics
- Code organization and best practices

**Key Code Example:**
\`\`\`javascript
function setupScrollAnimations() {
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  });

  const cards = document.querySelectorAll('.card');
  cards.forEach(function(card) {
    card.style.opacity = '0';
    observer.observe(card);
  });
}
\`\`\`

**Learning Focus:**
- Intersection Observer is more efficient than scroll events
- Progressive enhancement improves accessibility
- Clean code organization makes maintenance easier

## JavaScript Patterns Used (Beginner-Friendly)

### 1. Global Variables for State Management
\`\`\`javascript
let modal = null;
let currentSketch = null;
\`\`\`
Simple and easy to understand for beginners.

### 2. Function Declarations
\`\`\`javascript
function initializeApp() {
  // Initialization code
}
\`\`\`
Clear, readable, and hoisted for easy organization.

### 3. Event Handler Functions
\`\`\`javascript
function handleSketchButtonClick(event) {
  // Handle the click
}
\`\`\`
Separate functions for each type of event make code modular.

### 4. Factory Functions for p5.js
\`\`\`javascript
function createParticleSystemSketch() {
  return function(p) {
    // p5.js sketch code
  };
}
\`\`\`
Returns a function that p5.js can use, avoiding complex class syntax.

### 5. Utility Functions
\`\`\`javascript
function debounce(func, wait) {
  // Debouncing logic
}
\`\`\`
Reusable helper functions for common tasks.

## Key Differences from Class-Based Approach

| Class-Based | Function-Based |
|-------------|----------------|
| `new PortfolioModal()` | `initializeApp()` |
| `this.modal` | `let modal` |
| `this.openModal()` | `openModal()` |
| Constructor pattern | Initialization function |
| Method binding | Direct function calls |

## Assessment Criteria
Students will be evaluated on:
- Semantic HTML structure and accessibility compliance
- Proper use of CSS Grid for layout and Flexbox for components
- Clean, readable JavaScript using functions
- Responsive design implementation
- Working p5.js integration
- Code organization and commenting

## Workshop Benefits
- **Beginner-Friendly**: No complex OOP concepts required
- **Modern Standards**: Uses latest HTML5, CSS3, and ES6+ features
- **Practical Skills**: Builds a real portfolio website
- **Scalable**: Easy to extend with more sketches and features
- **Accessible**: Follows web accessibility best practices

## Next Steps After Workshop
1. Add your own p5.js sketches to the portfolio
2. Customize the design and colors
3. Add more interactive features (search, categories, etc.)
4. Deploy to GitHub Pages or Netlify
5. Learn more advanced JavaScript concepts gradually

This simplified approach makes web standards accessible to beginners while still teaching modern, professional development practices.
