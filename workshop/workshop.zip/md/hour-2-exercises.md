# Hour 2: CSS Grid Mastery
## Guided Coding Exercises

### Exercise 2.1: Understanding CSS Grid Basics (20 minutes)

**Objective:** Learn how CSS Grid creates two-dimensional layouts.

**Step 1:** Create a simple grid container
\`\`\`css
/* Add this to your CSS file */
.portfolio__grid {
    display: grid;
    background-color: #f0f0f0; /* Temporary - to see the grid */
    padding: 1rem;
}
\`\`\`

**What you learned:**
- `display: grid` turns an element into a grid container
- All direct children become grid items automatically

**Step 2:** Define grid columns
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr; /* Three equal columns */
    background-color: #f0f0f0;
    padding: 1rem;
}
\`\`\`

**Test it:** Add three cards to see them arrange in columns.

**What you learned:**
- `1fr` means "1 fraction of available space"
- `grid-template-columns` defines how many columns and their sizes

**Step 3:** Add gaps between grid items
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 2rem; /* Space between all grid items */
    background-color: #f0f0f0;
    padding: 1rem;
}
\`\`\`

**What you learned:**
- `gap` adds space between grid items (not around the edges)
- It's shorthand for `row-gap` and `column-gap`

### Exercise 2.2: Making the Grid Responsive (25 minutes)

**Step 1:** Use repeat() for cleaner code
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* Same as 1fr 1fr 1fr */
    gap: 2rem;
    padding: 1rem;
}
\`\`\`

**What you learned:**
- `repeat(3, 1fr)` is cleaner than writing `1fr` three times
- First number is how many times to repeat, second is what to repeat

**Step 2:** Add minimum and maximum sizes
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(300px, 1fr));
    gap: 2rem;
    padding: 1rem;
}
\`\`\`

**Test it:** Resize your browser window. Cards won't get smaller than 300px.

**What you learned:**
- `minmax(300px, 1fr)` sets minimum 300px, maximum 1 fraction
- This prevents cards from becoming too narrow

**Step 3:** Make it truly responsive with auto-fit
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
    padding: 1rem;
}
\`\`\`

**Test it:** Resize your browser. The number of columns changes automatically!

**What you learned:**
- `auto-fit` automatically adjusts the number of columns
- Cards will wrap to new rows when they can't fit
- No media queries needed for basic responsiveness!

### Exercise 2.3: Grid Alignment and Positioning (15 minutes)

**Step 1:** Align grid items
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
    align-items: start; /* Align items to top of their grid area */
    justify-items: center; /* Center items horizontally */
}
\`\`\`

**What you learned:**
- `align-items` controls vertical alignment
- `justify-items` controls horizontal alignment
- Options: `start`, `end`, `center`, `stretch`

**Step 2:** Align the entire grid
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
    justify-content: center; /* Center the entire grid */
}
\`\`\`

**What you learned:**
- `justify-content` aligns the entire grid within its container
- Useful when grid is smaller than its container

### Exercise 2.4: Advanced Grid Techniques (20 minutes)

**Step 1:** Create a featured card that spans multiple columns
\`\`\`html
<!-- Add this as your first card -->
<article class="card card--featured">
    <div class="card__preview">
        <img src="/placeholder.svg?height=300&width=600" 
             alt="Featured artwork showcase" 
             class="card__image">
    </div>
    <div class="card__content">
        <h3 class="card__title">Featured: Interactive Galaxy</h3>
        <p class="card__description">My latest creation - an interactive galaxy simulation with thousands of stars</p>
        <button class="btn btn--primary" data-sketch="galaxy">View Sketch</button>
    </div>
</article>
\`\`\`

\`\`\`css
.card--featured {
    grid-column: span 2; /* Span across 2 columns */
}

/* Make it work on smaller screens too */
@media (max-width: 768px) {
    .card--featured {
        grid-column: span 1; /* Only span 1 column on mobile */
    }
}
\`\`\`

**What you learned:**
- `grid-column: span 2` makes an item span multiple columns
- Media queries can change grid behavior at different screen sizes

**Step 2:** Create a grid within a grid (nested grid)
\`\`\`css
.card__content {
    display: grid;
    grid-template-rows: auto 1fr auto; /* Title, description, button */
    gap: 1rem;
    padding: 1.5rem;
    height: 100%; /* Fill the card height */
}

.card__description {
    align-self: start; /* Align description to top */
}

.btn {
    align-self: end; /* Push button to bottom */
}
\`\`\`

**What you learned:**
- You can use grid inside grid items (nested grids)
- `grid-template-rows` defines row sizes
- `auto` means "size to content", `1fr` means "take remaining space"

### Hour 2 Challenge: Create a Complex Grid Layout

**Your Task:** Create a grid that has:
- 1 featured card spanning 2 columns at the top
- 4 regular cards below in a 2x2 grid
- Responsive behavior for mobile

**Solution:**
\`\`\`css
.portfolio__grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.card--featured {
    grid-column: 1 / -1; /* Span from first to last column */
}

@media (min-width: 768px) {
    .portfolio__grid {
        grid-template-columns: repeat(4, 1fr);
    }
    
    .card--featured {
        grid-column: 1 / 3; /* Span first 2 columns */
    }
}
\`\`\`

### Debugging Grid Layouts

**Use Firefox Grid Inspector:**
1. Right-click on your grid container
2. Choose "Inspect Element"
3. Look for the grid icon next to `display: grid`
4. Click it to see grid lines!

**Common Grid Issues:**
- **Cards different heights?** Use `align-items: stretch` (default)
- **Grid too wide?** Add `max-width` to container
- **Items not filling space?** Check if you're using `1fr` correctly

### Key Takeaways from Hour 2:
- ✅ CSS Grid is perfect for two-dimensional layouts
- ✅ `repeat()` and `minmax()` create flexible, responsive grids
- ✅ `auto-fit` eliminates the need for many media queries
- ✅ Grid items can span multiple columns with `grid-column: span X`
- ✅ Nested grids allow complex layouts within grid items
- ✅ Firefox Grid Inspector is your best debugging tool
