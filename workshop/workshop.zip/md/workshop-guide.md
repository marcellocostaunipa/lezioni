# 8-Hour Web Standards Workshop: Building a p5.js Portfolio

## Workshop Overview
This comprehensive workshop teaches modern web standards through building a portfolio website for p5.js creative coding projects. Students will learn HTML5, CSS3, and JavaScript while creating a fully functional, responsive portfolio.

## Learning Objectives
By the end of this workshop, participants will:
- Understand semantic HTML5 structure and accessibility
- Master CSS Grid and Flexbox for modern layouts
- Implement responsive design principles
- Use the new HTML `<dialog>` element
- Write clean, modular JavaScript
- Integrate p5.js sketches into web applications
- Apply web performance best practices

## Workshop Schedule (8 Hours)

### Hour 1: HTML5 Foundations & Semantic Structure
**Topics Covered:**
- Modern HTML5 document structure
- Semantic elements (`<header>`, `<main>`, `<article>`, `<section>`)
- Accessibility best practices (ARIA, alt text, semantic markup)
- The new `<dialog>` element
- Meta tags and viewport configuration

**Hands-on Activity:**
- Build the basic HTML structure for the portfolio
- Implement semantic markup for cards and modal
- Add proper accessibility attributes

**Key Code Examples:**
\`\`\`html
<!-- Semantic structure -->
<header class="header">
  <div class="container">
    <h1 class="header__title">Creative Coding Portfolio</h1>
  </div>
</header>

<!-- Modern dialog element -->
<dialog class="modal" id="sketch-modal">
  <div class="modal__content">
    <!-- Modal content -->
  </div>
</dialog>
\`\`\`

### Hour 2: CSS Grid Mastery
**Topics Covered:**
- CSS Grid fundamentals
- Grid template areas and lines
- Responsive grid layouts
- Auto-fit vs auto-fill
- Grid gap and alignment

**Hands-on Activity:**
- Create the portfolio grid layout
- Implement responsive grid behavior
- Practice grid alignment techniques

**Key Code Examples:**
\`\`\`css
.portfolio__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
}
\`\`\`

### Hour 3: CSS Flexbox for Components
**Topics Covered:**
- Flexbox fundamentals
- Flex direction, wrap, and alignment
- Flex grow, shrink, and basis
- Building flexible components

**Hands-on Activity:**
- Style card components with flexbox
- Create flexible button components
- Implement modal header layout

**Key Code Examples:**
\`\`\`css
.card__content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}
\`\`\`

### Hour 4: Advanced CSS & Responsive Design
**Topics Covered:**
- CSS custom properties (variables)
- Advanced selectors and pseudo-elements
- CSS animations and transitions
- Media queries and responsive design
- CSS Grid and Flexbox integration

**Hands-on Activity:**
- Add hover effects and animations
- Implement responsive breakpoints
- Create smooth transitions

**Key Code Examples:**
\`\`\`css
:root {
  --primary-color: #667eea;
  --secondary-color: #764ba2;
}

@media (max-width: 768px) {
  .portfolio__grid {
    grid-template-columns: 1fr;
  }
}
\`\`\`

### Hour 5: JavaScript Fundamentals & DOM Manipulation
**Topics Covered:**
- Modern JavaScript (ES6+)
- DOM selection and manipulation
- Event handling and delegation
- Classes and modules
- Arrow functions and destructuring

**Hands-on Activity:**
- Create the PortfolioModal class
- Implement event listeners
- Add keyboard navigation

**Key Code Examples:**
\`\`\`javascript
class PortfolioModal {
  constructor() {
    this.modal = document.getElementById('sketch-modal');
    this.init();
  }
  
  init() {
    const buttons = document.querySelectorAll('[data-sketch]');
    buttons.forEach(button => {
      button.addEventListener('click', this.handleClick.bind(this));
    });
  }
}
\`\`\`

### Hour 6: p5.js Integration & Canvas Management
**Topics Covered:**
- p5.js instance mode
- Canvas creation and management
- Animation loops and performance
- Responsive canvas sizing
- Multiple sketch management

**Hands-on Activity:**
- Create placeholder p5.js sketches
- Implement sketch loading system
- Add canvas responsiveness

**Key Code Examples:**
\`\`\`javascript
particleSystemSketch = (p) => {
  p.setup = () => {
    const canvas = p.createCanvas(800, 600);
    canvas.parent(this.sketchContainer);
  };
  
  p.draw = () => {
    p.background(20, 25, 40);
    // Animation code
  };
};
\`\`\`

### Hour 7: Performance & Accessibility
**Topics Covered:**
- Web performance optimization
- Lazy loading and intersection observers
- Accessibility testing and implementation
- Keyboard navigation
- Screen reader compatibility

**Hands-on Activity:**
- Implement intersection observer for animations
- Add keyboard shortcuts
- Test with screen readers
- Optimize performance

**Key Code Examples:**
\`\`\`javascript
class AnimationObserver {
  constructor() {
    this.observer = new IntersectionObserver(
      (entries) => this.handleIntersection(entries),
      { threshold: 0.1 }
    );
  }
}
\`\`\`

### Hour 8: Final Integration & Best Practices
**Topics Covered:**
- Code organization and modularity
- Error handling and debugging
- Browser compatibility
- Deployment considerations
- Code review and optimization

**Hands-on Activity:**
- Complete the portfolio integration
- Test across different browsers
- Optimize for production
- Code review session

## Key Learning Points

### HTML5 Best Practices
1. **Semantic Structure**: Use appropriate HTML5 elements
2. **Accessibility**: Implement ARIA labels and proper markup
3. **Modern Elements**: Utilize `<dialog>` for modals
4. **Meta Tags**: Proper viewport and SEO configuration

### CSS Architecture
1. **BEM Methodology**: Block, Element, Modifier naming
2. **Grid vs Flexbox**: When to use each layout method
3. **Responsive Design**: Mobile-first approach
4. **Performance**: Efficient selectors and animations

### JavaScript Patterns
1. **ES6+ Features**: Classes, arrow functions, destructuring
2. **Event Delegation**: Efficient event handling
3. **Modular Code**: Separation of concerns
4. **Error Handling**: Graceful degradation

### p5.js Integration
1. **Instance Mode**: Multiple sketches management
2. **Responsive Canvas**: Dynamic sizing
3. **Performance**: Efficient animation loops
4. **Cleanup**: Proper resource management

## Assessment Criteria
Students will be evaluated on:
- Semantic HTML structure and accessibility
- Proper use of CSS Grid and Flexbox
- Clean, modular JavaScript code
- Responsive design implementation
- p5.js integration quality
- Code organization and best practices

## Resources for Continued Learning
- [MDN Web Docs](https://developer.mozilla.org/)
- [CSS Grid Garden](https://cssgridgarden.com/)
- [Flexbox Froggy](https://flexboxfroggy.com/)
- [p5.js Reference](https://p5js.org/reference/)
- [Web Accessibility Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)

## Workshop Files Structure
\`\`\`
workshop-project/
├── index.html          # Main HTML structure
├── styles.css          # Complete CSS styling
├── script.js           # JavaScript functionality
├── workshop-guide.md   # This guide
└── assets/
    ├── images/         # Placeholder images
    └── sketches/       # p5.js sketch files
\`\`\`

## Next Steps
After completing this workshop, students should:
1. Create their own p5.js sketches
2. Customize the portfolio design
3. Add more interactive features
4. Deploy to a web hosting service
5. Continue learning advanced web technologies
