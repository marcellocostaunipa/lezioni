# Hour 6: Modal Functionality & DOM Manipulation
## Guided Coding Exercises

### Exercise 6.1: Advanced Modal Management (25 minutes)

**Objective:** Create a robust modal system with proper state management and accessibility.

**Step 1:** Enhance the modal opening function
\`\`\`javascript
// Track modal state more precisely
let modalState = {
    isOpen: false,
    currentSketch: null,
    previousFocus: null
};

function openModal(sketchId, title) {
    console.log('Opening modal for:', sketchId, title);
    
    // Store what element had focus before opening modal
    modalState.previousFocus = document.activeElement;
    
    // Update modal state
    modalState.isOpen = true;
    modalState.currentSketch = sketchId;
    
    // Set the modal title
    modalTitle.textContent = title;
    
    // Show loading state
    showLoadingState(sketchId);
    
    // Show the modal
    modal.showModal();
    
    // Prevent body scroll
    document.body.style.overflow = 'hidden';
    
    // Focus the close button for accessibility
    closeButton.focus();
    
    // Add escape key handling
    modal.setAttribute('aria-hidden', 'false');
    
    console.log('Modal opened successfully');
}

function showLoadingState(sketchId) {
    const sketchInfo = getSketchInfo(sketchId);
    
    sketchContainer.innerHTML = `
        <div class="modal__loading" style="
            color: white; 
            text-align: center; 
            padding: 2rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        ">
            <div class="loading-spinner" style="
                width: 40px; 
                height: 40px; 
                border: 3px solid rgba(255,255,255,0.3);
                border-top: 3px solid white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin-bottom: 1rem;
            "></div>
            <h3 style="margin-bottom: 0.5rem;">${sketchInfo.title}</h3>
            <p style="opacity: 0.8; margin-bottom: 1rem;">${sketchInfo.description}</p>
            <p style="opacity: 0.6;">Loading sketch...</p>
        </div>
    `;
}
\`\`\`

**What you learned:**
- Objects can track complex state
- `document.activeElement` tells you what's focused
- `setAttribute()` changes HTML attributes
- Accessibility requires focus management

**Step 2:** Improve the modal closing function
\`\`\`javascript
function closeModal() {
    console.log('Closing modal');
    
    // Check if modal is actually open
    if (!modalState.isOpen) {
        console.log('Modal already closed');
        return;
    }
    
    // Hide the modal
    modal.close();
    
    // Clean up the sketch container
    cleanupSketchContainer();
    
    // Update modal state
    modalState.isOpen = false;
    modalState.currentSketch = null;
    
    // Restore body scroll
    document.body.style.overflow = '';
    
    // Restore focus to previous element
    if (modalState.previousFocus) {
        modalState.previousFocus.focus();
        modalState.previousFocus = null;
    }
    
    // Update accessibility attributes
    modal.setAttribute('aria-hidden', 'true');
    
    console.log('Modal closed successfully');
}

function cleanupSketchContainer() {
    // Clear any running animations or timers
    const loadingElements = sketchContainer.querySelectorAll('.loading-spinner');
    loadingElements.forEach(function(element) {
        element.remove();
    });
    
    // Clear the container
    sketchContainer.innerHTML = '';
    
    console.log('Sketch container cleaned up');
}
\`\`\`

**What you learned:**
- Always check state before performing actions
- Clean up resources when closing
- Restore focus for keyboard users
- Remove specific elements with `querySelectorAll()` and `remove()`

**Step 3:** Add modal animation and transitions
\`\`\`javascript
function openModal(sketchId, title) {
    // ... previous code ...
    
    // Add opening animation class
    modal.classList.add('modal--opening');
    
    // Remove animation class after animation completes
    setTimeout(function() {
        modal.classList.remove('modal--opening');
    }, 300);
    
    // ... rest of function
}

function closeModal() {
    // Add closing animation
    modal.classList.add('modal--closing');
    
    // Wait for animation before actually closing
    setTimeout(function() {
        modal.close();
        modal.classList.remove('modal--closing');
        
        // ... rest of cleanup code
    }, 200);
    
    // Update state immediately
    modalState.isOpen = false;
}
\`\`\`

**Add corresponding CSS:**
\`\`\`css
.modal--opening {
    animation: modalFadeIn 0.3s ease;
}

.modal--closing {
    animation: modalFadeOut 0.2s ease;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: translate(-50%, -50%) scale(0.9);
    }
    to {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
    }
}

@keyframes modalFadeOut {
    from {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
    }
    to {
        opacity: 0;
        transform: translate(-50%, -50%) scale(0.9);
    }
}
\`\`\`

### Exercise 6.2: Dynamic Content Creation (20 minutes)

**Step 1:** Create a function to build sketch information
\`\`\`javascript
function createSketchInfoHTML(sketchInfo) {
    // Create the main container
    const container = document.createElement('div');
    container.className = 'sketch-info';
    container.style.cssText = `
        color: white;
        text-align: center;
        padding: 2rem;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
    `;
    
    // Create title
    const title = document.createElement('h3');
    title.textContent = sketchInfo.title;
    title.style.cssText = 'margin-bottom: 1rem; font-size: 1.5rem;';
    
    // Create description
    const description = document.createElement('p');
    description.textContent = sketchInfo.description;
    description.style.cssText = 'margin-bottom: 1rem; opacity: 0.9; line-height: 1.6;';
    
    // Create difficulty badge
    const difficulty = document.createElement('span');
    difficulty.textContent = sketchInfo.difficulty;
    difficulty.className = 'difficulty-badge difficulty-badge--' + sketchInfo.difficulty.toLowerCase();
    difficulty.style.cssText = `
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.875rem;
        font-weight: 500;
        margin-bottom: 1rem;
        background: rgba(255, 255, 255, 0.2);
    `;
    
    // Create tags container
    const tagsContainer = document.createElement('div');
    tagsContainer.style.cssText = 'margin-bottom: 1.5rem;';
    
    const tagsLabel = document.createElement('p');
    tagsLabel.textContent = 'Tags: ';
    tagsLabel.style.cssText = 'opacity: 0.7; margin-bottom: 0.5rem;';
    
    const tagsList = document.createElement('div');
    tagsList.style.cssText = 'display: flex; flex-wrap: wrap; gap: 0.5rem; justify-content: center;';
    
    // Create individual tag elements
    sketchInfo.tags.forEach(function(tag) {
        const tagElement = document.createElement('span');
        tagElement.textContent = tag;
        tagElement.style.cssText = `
            background: rgba(255, 255, 255, 0.1);
            padding: 0.25rem 0.5rem;
            border-radius: 0.5rem;
            font-size: 0.75rem;
            opacity: 0.8;
        `;
        tagsList.appendChild(tagElement);
    });
    
    // Assemble the elements
    container.appendChild(title);
    container.appendChild(description);
    container.appendChild(difficulty);
    tagsContainer.appendChild(tagsLabel);
    tagsContainer.appendChild(tagsList);
    container.appendChild(tagsContainer);
    
    return container;
}
\`\`\`

**What you learned:**
- `document.createElement()` creates new HTML elements
- `appendChild()` adds elements to containers
- `cssText` sets multiple CSS properties at once
- Building HTML with JavaScript gives you more control

**Step 2:** Use the dynamic content function
\`\`\`javascript
function showSketchInfo(sketchId) {
    const sketchInfo = getSketchInfo(sketchId);
    
    // Clear container and add new content
    sketchContainer.innerHTML = '';
    
    // Create and add the sketch info
    const infoElement = createSketchInfoHTML(sketchInfo);
    sketchContainer.appendChild(infoElement);
    
    // Add a "Start Sketch" button
    const startButton = document.createElement('button');
    startButton.textContent = 'Start Sketch';
    startButton.className = 'btn btn--primary';
    startButton.style.cssText = 'margin-top: 1rem;';
    
    startButton.addEventListener('click', function() {
        console.log('Starting sketch:', sketchId);
        // We'll implement sketch loading in the next hour
        showSketchPlaceholder(sketchId);
    });
    
    infoElement.appendChild(startButton);
}

function showSketchPlaceholder(sketchId) {
    sketchContainer.innerHTML = `
        <div style="
            color: white; 
            text-align: center; 
            padding: 2rem;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div>
                <h3 style="margin-bottom: 1rem;">🎨 ${sketchId}</h3>
                <p style="opacity: 0.8;">Sketch is running!</p>
                <p style="opacity: 0.6; margin-top: 1rem; font-size: 0.875rem;">
                    (p5.js integration coming in Hour 7)
                </p>
            </div>
        </div>
    `;
}

// Update the openModal function to use the new system
function openModal(sketchId, title) {
    console.log('Opening modal for:', sketchId, title);
    
    modalState.previousFocus = document.activeElement;
    modalState.isOpen = true;
    modalState.currentSketch = sketchId;
    
    modalTitle.textContent = title;
    
    // Show loading, then info
    showLoadingState(sketchId);
    
    modal.showModal();
    document.body.style.overflow = 'hidden';
    closeButton.focus();
    
    // Simulate loading time, then show sketch info
    setTimeout(function() {
        showSketchInfo(sketchId);
    }, 1500);
}
\`\`\`

### Exercise 6.3: Form Handling and User Input (15 minutes)

**Step 1:** Add a search feature to filter sketches
\`\`\`html
<!-- Add this to your HTML before the portfolio grid -->
<div class="search-container">
    <input type="text" 
           id="sketch-search" 
           class="search-input" 
           placeholder="Search sketches..."
           aria-label="Search sketches">
    <button class="search-clear" id="search-clear" aria-label="Clear search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
    </button>
</div>
\`\`\`

**Step 2:** Implement search functionality
\`\`\`javascript
let searchInput = null;
let searchClearButton = null;
let allCards = null;

function initializeSearch() {
    searchInput = document.getElementById('sketch-search');
    searchClearButton = document.getElementById('search-clear');
    allCards = document.querySelectorAll('.card');
    
    if (!searchInput || !searchClearButton) {
        console.log('Search elements not found');
        return;
    }
    
    // Add event listeners
    searchInput.addEventListener('input', handleSearchInput);
    searchClearButton.addEventListener('click', clearSearch);
    
    console.log('Search initialized');
}

function handleSearchInput(event) {
    const searchTerm = event.target.value.toLowerCase().trim();
    
    console.log('Searching for:', searchTerm);
    
    // Show/hide clear button
    if (searchTerm.length > 0) {
        searchClearButton.style.display = 'flex';
    } else {
        searchClearButton.style.display = 'none';
    }
    
    // Filter cards
    filterCards(searchTerm);
}

function filterCards(searchTerm) {
    let visibleCount = 0;
    
    allCards.forEach(function(card) {
        const title = card.querySelector('.card__title').textContent.toLowerCase();
        const description = card.querySelector('.card__description').textContent.toLowerCase();
        
        // Check if search term matches title or description
        const matches = title.includes(searchTerm) || description.includes(searchTerm);
        
        if (matches || searchTerm === '') {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    // Show message if no results
    showSearchResults(visibleCount, searchTerm);
}

function showSearchResults(count, searchTerm) {
    // Remove existing message
    const existingMessage = document.querySelector('.search-results');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Add message if needed
    if (searchTerm && count === 0) {
        const message = document.createElement('div');
        message.className = 'search-results';
        message.style.cssText = `
            text-align: center;
            padding: 2rem;
            color: #718096;
            grid-column: 1 / -1;
        `;
        message.innerHTML = `
            <p>No sketches found for "${searchTerm}"</p>
            <button onclick="clearSearch()" style="
                margin-top: 1rem;
                padding: 0.5rem 1rem;
                border: 1px solid #cbd5e0;
                border-radius: 0.5rem;
                background: white;
                cursor: pointer;
            ">Clear search</button>
        `;
        
        document.querySelector('.portfolio__grid').appendChild(message);
    }
}

function clearSearch() {
    searchInput.value = '';
    searchClearButton.style.display = 'none';
    filterCards('');
}

// Update initializeApp to include search
function initializeApp() {
    // ... existing code ...
    
    initializeSearch();
}
\`\`\`

**What you learned:**
- `input` event fires as user types
- `includes()` checks if text contains a substring
- `toLowerCase()` makes search case-insensitive
- Dynamic DOM manipulation for search results

### Hour 6 Challenge: Add Keyboard Navigation

**Your Task:** Add keyboard navigation to browse through cards using arrow keys.

**Solution:**
\`\`\`javascript
let currentCardIndex = 0;

function initializeKeyboardNavigation() {
    // Make cards focusable
    allCards.forEach(function(card, index) {
        card.setAttribute('tabindex', index === 0 ? '0' : '-1');
        card.setAttribute('data-index', index);
        
        // Add visual focus indicator
        card.addEventListener('focus', function() {
            card.style.outline = '2px solid #667eea';
            card.style.outlineOffset = '2px';
        });
        
        card.addEventListener('blur', function() {
            card.style.outline = 'none';
        });
        
        // Allow Enter to open modal
        card.addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                const button = card.querySelector('[data-sketch]');
                if (button) {
                    button.click();
                }
            }
        });
    });
}

function handleCardNavigation(event) {
    const visibleCards = Array.from(allCards).filter(function(card) {
        return card.style.display !== 'none';
    });
    
    if (visibleCards.length === 0) return;
    
    let newIndex = currentCardIndex;
    
    switch(event.key) {
        case 'ArrowRight':
        case 'ArrowDown':
            newIndex = (currentCardIndex + 1) % visibleCards.length;
            break;
        case 'ArrowLeft':
        case 'ArrowUp':
            newIndex = (currentCardIndex - 1 + visibleCards.length) % visibleCards.length;
            break;
        default:
            return; // Don't prevent default for other keys
    }
    
    event.preventDefault();
    
    // Update focus
    visibleCards[currentCardIndex].setAttribute('tabindex', '-1');
    visibleCards[newIndex].setAttribute('tabindex', '0');
    visibleCards[newIndex].focus();
    
    currentCardIndex = newIndex;
}

// Add to setupEventListeners
function setupEventListeners() {
    // ... existing listeners ...
    
    document.addEventListener('keydown', function(event) {
        // Only handle navigation when not in modal
        if (!modalState.isOpen) {
            handleCardNavigation(event);
        }
        
        handleKeyboardInput(event);
    });
}
\`\`\`

### Accessibility Best Practices

**1. Focus Management:**
\`\`\`javascript
function trapFocusInModal() {
    const focusableElements = modal.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    modal.addEventListener('keydown', function(event) {
        if (event.key === 'Tab') {
            if (event.shiftKey) {
                // Shift + Tab
                if (document.activeElement === firstElement) {
                    event.preventDefault();
                    lastElement.focus();
                }
            } else {
                // Tab
                if (document.activeElement === lastElement) {
                    event.preventDefault();
                    firstElement.focus();
                }
            }
        }
    });
}
\`\`\`

**2. Screen Reader Announcements:**
\`\`\`javascript
function announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.style.cssText = `
        position: absolute;
        left: -10000px;
        width: 1px;
        height: 1px;
        overflow: hidden;
    `;
    announcement.textContent = message;
    
    document.body.appendChild(announcement);
    
    setTimeout(function() {
        document.body.removeChild(announcement);
    }, 1000);
}

// Use it when opening modals
function openModal(sketchId, title) {
    // ... existing code ...
    
    announceToScreenReader('Modal opened: ' + title);
}
\`\`\`

### Key Takeaways from Hour 6:
- ✅ Proper state management prevents bugs
- ✅ Focus management is crucial for accessibility
- ✅ Dynamic content creation gives you full control
- ✅ Event delegation handles multiple similar elements
- ✅ Always clean up resources when done
- ✅ Keyboard navigation improves usability
- ✅ Screen reader support makes content accessible to all users
