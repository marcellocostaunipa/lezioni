# Hour 5: JavaScript Fundamentals (Function-Based)
## Guided Coding Exercises

### Exercise 5.1: Variables and DOM Selection (20 minutes)

**Objective:** Learn to store references to DOM elements and manage application state.

**Step 1:** Understand different variable types
\`\`\`javascript
// Global variables - accessible everywhere
let modal = null;
let currentSketch = null;
let isModalOpen = false;

// Constants - values that never change
const ANIMATION_DURATION = 300;
const SKETCH_CONTAINER_ID = 'sketch-container';

// Function to demonstrate variable scope
function demonstrateScope() {
    // Local variable - only accessible inside this function
    let localMessage = "This is local";
    console.log(localMessage);
    
    // Can access global variables
    console.log("Modal exists:", modal !== null);
}
\`\`\`

**What you learned:**
- `let` creates variables that can change
- `const` creates variables that cannot be reassigned
- Global variables are accessible everywhere
- Local variables only exist inside their function

**Step 2:** Select DOM elements
\`\`\`javascript
// Wait for the page to load completely
document.addEventListener('DOMContentLoaded', function() {
    // Select single elements by ID
    modal = document.getElementById('sketch-modal');
    const modalTitle = document.getElementById('modal-title');
    const sketchContainer = document.getElementById('sketch-container');
    const closeButton = document.getElementById('close-modal');
    
    // Select multiple elements
    const allCards = document.querySelectorAll('.card');
    const allButtons = document.querySelectorAll('[data-sketch]');
    
    // Log what we found
    console.log('Found modal:', modal);
    console.log('Found', allCards.length, 'cards');
    console.log('Found', allButtons.length, 'sketch buttons');
});
\`\`\`

**What you learned:**
- `getElementById()` finds one element by its ID
- `querySelectorAll()` finds all elements matching a CSS selector
- `DOMContentLoaded` ensures the page is ready before running code
- Always check if elements exist before using them

**Step 3:** Store element references globally
\`\`\`javascript
// Global variables for important elements
let modal = null;
let modalTitle = null;
let sketchContainer = null;
let closeButton = null;
let allSketchButtons = null;

function initializeApp() {
    // Get references to important DOM elements
    modal = document.getElementById('sketch-modal');
    modalTitle = document.getElementById('modal-title');
    sketchContainer = document.getElementById('sketch-container');
    closeButton = document.getElementById('close-modal');
    allSketchButtons = document.querySelectorAll('[data-sketch]');
    
    // Check if we found everything
    if (!modal || !modalTitle || !sketchContainer || !closeButton) {
        console.error('Could not find required elements!');
        return;
    }
    
    console.log('App initialized successfully!');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', initializeApp);
\`\`\`

**What you learned:**
- Store element references globally for easy access
- Always check if elements exist before using them
- Use descriptive variable names
- Initialize everything in one function

### Exercise 5.2: Event Listeners and Functions (25 minutes)

**Step 1:** Create your first event listener
\`\`\`javascript
function handleCloseButtonClick() {
    console.log('Close button was clicked!');
    // We'll add modal closing logic later
}

function setupEventListeners() {
    // Add click listener to close button
    closeButton.addEventListener('click', handleCloseButtonClick);
    
    console.log('Event listeners set up!');
}

function initializeApp() {
    // ... previous code ...
    
    // Set up event listeners after getting elements
    setupEventListeners();
}
\`\`\`

**What you learned:**
- `addEventListener()` connects user actions to functions
- Separate functions for different event handlers
- Keep initialization organized

**Step 2:** Handle multiple buttons with a loop
\`\`\`javascript
function handleSketchButtonClick(event) {
    // Get information about the clicked button
    const button = event.currentTarget;
    const sketchId = button.getAttribute('data-sketch');
    
    console.log('Sketch button clicked:', sketchId);
    
    // Find the card this button belongs to
    const card = button.closest('.card');
    const cardTitle = card.querySelector('.card__title').textContent;
    
    console.log('Card title:', cardTitle);
}

function setupEventListeners() {
    // Close button listener
    closeButton.addEventListener('click', handleCloseButtonClick);
    
    // Add listeners to all sketch buttons
    allSketchButtons.forEach(function(button) {
        button.addEventListener('click', handleSketchButtonClick);
    });
    
    console.log('Event listeners set up!');
}
\`\`\`

**What you learned:**
- `event.currentTarget` is the element that has the listener
- `getAttribute()` gets custom data attributes
- `closest()` finds the nearest parent element
- `forEach()` runs a function for each item in a list

**Step 3:** Add keyboard event handling
\`\`\`javascript
function handleKeyboardInput(event) {
    console.log('Key pressed:', event.key);
    
    // Close modal when Escape is pressed
    if (event.key === 'Escape' && isModalOpen) {
        console.log('Escape pressed - closing modal');
        closeModal();
    }
    
    // Navigation shortcuts
    if (!event.ctrlKey && !event.metaKey) {
        if (event.key === 'h') {
            console.log('Scrolling to header');
            scrollToElement('.header');
        } else if (event.key === 'p') {
            console.log('Scrolling to portfolio');
            scrollToElement('.portfolio');
        }
    }
}

function scrollToElement(selector) {
    const element = document.querySelector(selector);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

function setupEventListeners() {
    // ... previous listeners ...
    
    // Add keyboard listener to entire document
    document.addEventListener('keydown', handleKeyboardInput);
}
\`\`\`

**What you learned:**
- `keydown` event fires when any key is pressed
- `event.key` tells you which key was pressed
- Check modifier keys like Ctrl and Meta (Cmd)
- `scrollIntoView()` smoothly scrolls to elements

### Exercise 5.3: Modal Functions (20 minutes)

**Step 1:** Create modal opening function
\`\`\`javascript
function openModal(sketchId, title) {
    console.log('Opening modal for:', sketchId, title);
    
    // Set the modal title
    modalTitle.textContent = title;
    
    // Show a placeholder for now
    sketchContainer.innerHTML = '<p style="color: white; text-align: center;">Loading ' + sketchId + '...</p>';
    
    // Show the modal
    modal.showModal();
    
    // Update our state
    isModalOpen = true;
    
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';
    
    console.log('Modal opened successfully');
}
\`\`\`

**What you learned:**
- Functions can accept parameters (inputs)
- `textContent` safely sets text content
- `innerHTML` sets HTML content (be careful with user input!)
- `showModal()` is the modern way to show dialogs

**Step 2:** Create modal closing function
\`\`\`javascript
function closeModal() {
    console.log('Closing modal');
    
    // Hide the modal
    modal.close();
    
    // Clear the sketch container
    sketchContainer.innerHTML = '';
    
    // Update our state
    isModalOpen = false;
    
    // Restore body scroll
    document.body.style.overflow = '';
    
    console.log('Modal closed successfully');
}
\`\`\`

**Step 3:** Update event handlers to use modal functions
\`\`\`javascript
function handleCloseButtonClick() {
    closeModal();
}

function handleSketchButtonClick(event) {
    const button = event.currentTarget;
    const sketchId = button.getAttribute('data-sketch');
    
    const card = button.closest('.card');
    const cardTitle = card.querySelector('.card__title').textContent;
    
    // Open the modal with the sketch
    openModal(sketchId, cardTitle);
}

function handleModalBackdropClick(event) {
    // Close modal if user clicks outside the content
    if (event.target === modal) {
        closeModal();
    }
}

function setupEventListeners() {
    closeButton.addEventListener('click', handleCloseButtonClick);
    modal.addEventListener('click', handleModalBackdropClick);
    
    allSketchButtons.forEach(function(button) {
        button.addEventListener('click', handleSketchButtonClick);
    });
    
    document.addEventListener('keydown', handleKeyboardInput);
}
\`\`\`

**What you learned:**
- Functions can call other functions
- Modal backdrop clicks should close the modal
- Keep functions focused on one task

### Exercise 5.4: Data Management and State (15 minutes)

**Step 1:** Create a simple data structure for sketches
\`\`\`javascript
// Sketch information database
const sketchDatabase = {
    'particle-system': {
        title: 'Particle System',
        description: 'Interactive particles with physics simulation',
        difficulty: 'Beginner',
        tags: ['particles', 'physics', 'interactive']
    },
    'fractal-tree': {
        title: 'Fractal Tree',
        description: 'Recursive tree generation with dynamic growth',
        difficulty: 'Intermediate',
        tags: ['fractals', 'recursion', 'nature']
    },
    'sound-waves': {
        title: 'Sound Waves',
        description: 'Audio-reactive visualization with frequency analysis',
        difficulty: 'Advanced',
        tags: ['audio', 'visualization', 'waves']
    }
};

function getSketchInfo(sketchId) {
    const info = sketchDatabase[sketchId];
    if (info) {
        return info;
    } else {
        console.warn('Sketch not found:', sketchId);
        return {
            title: 'Unknown Sketch',
            description: 'This sketch is still in development',
            difficulty: 'Unknown',
            tags: []
        };
    }
}
\`\`\`

**Step 2:** Use the data in your modal
\`\`\`javascript
function openModal(sketchId, title) {
    console.log('Opening modal for:', sketchId);
    
    // Get detailed sketch information
    const sketchInfo = getSketchInfo(sketchId);
    
    // Set the modal title
    modalTitle.textContent = sketchInfo.title;
    
    // Create detailed content
    sketchContainer.innerHTML = `
        <div style="color: white; text-align: center; padding: 2rem;">
            <h3>${sketchInfo.title}</h3>
            <p style="margin: 1rem 0;">${sketchInfo.description}</p>
            <p style="opacity: 0.7;">Difficulty: ${sketchInfo.difficulty}</p>
            <p style="opacity: 0.7;">Tags: ${sketchInfo.tags.join(', ')}</p>
            <p style="margin-top: 2rem;">Sketch will load here...</p>
        </div>
    `;
    
    modal.showModal();
    isModalOpen = true;
    document.body.style.overflow = 'hidden';
}
\`\`\`

**What you learned:**
- Objects can store complex data
- Template literals (backticks) make HTML strings easier
- `join()` converts arrays to strings
- Always handle missing data gracefully

### Hour 5 Challenge: Add a Loading State

**Your Task:** Add a loading animation while sketches are "loading".

**Solution:**
\`\`\`javascript
function showLoadingState(sketchId) {
    sketchContainer.innerHTML = `
        <div style="color: white; text-align: center; padding: 2rem;">
            <div style="
                width: 40px; 
                height: 40px; 
                border: 3px solid rgba(255,255,255,0.3);
                border-top: 3px solid white;
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin: 0 auto 1rem;
            "></div>
            <p>Loading ${sketchId}...</p>
        </div>
    `;
}

function openModal(sketchId, title) {
    console.log('Opening modal for:', sketchId);
    
    modalTitle.textContent = title;
    
    // Show loading state first
    showLoadingState(sketchId);
    
    modal.showModal();
    isModalOpen = true;
    document.body.style.overflow = 'hidden';
    
    // Simulate loading time
    setTimeout(function() {
        const sketchInfo = getSketchInfo(sketchId);
        sketchContainer.innerHTML = `
            <div style="color: white; text-align: center; padding: 2rem;">
                <h3>${sketchInfo.title}</h3>
                <p style="margin: 1rem 0;">${sketchInfo.description}</p>
                <p style="opacity: 0.7;">Difficulty: ${sketchInfo.difficulty}</p>
                <p style="opacity: 0.7;">Tags: ${sketchInfo.tags.join(', ')}</p>
                <p style="margin-top: 2rem; color: #4ade80;">✓ Sketch loaded successfully!</p>
            </div>
        `;
    }, 1500); // Wait 1.5 seconds
}

// Add the CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);
\`\`\`

### Debugging JavaScript

**1. Use console.log() everywhere:**
\`\`\`javascript
function handleSketchButtonClick(event) {
    console.log('Button clicked!', event);
    
    const sketchId = event.currentTarget.getAttribute('data-sketch');
    console.log('Sketch ID:', sketchId);
    
    if (!sketchId) {
        console.error('No sketch ID found!');
        return;
    }
    
    // ... rest of function
}
\`\`\`

**2. Check the browser console:**
- Press F12 to open Developer Tools
- Click the "Console" tab
- Look for red error messages
- Use console.log() to track what's happening

**3. Common mistakes:**
- Forgetting to wait for `DOMContentLoaded`
- Trying to use elements that don't exist
- Typos in element IDs or class names
- Not checking if variables are null

### Key Takeaways from Hour 5:
- ✅ Variables store data and element references
- ✅ Functions organize code into reusable pieces
- ✅ Event listeners connect user actions to functions
- ✅ Always check if elements exist before using them
- ✅ Use console.log() to debug your code
- ✅ Keep functions small and focused on one task
