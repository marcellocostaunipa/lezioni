# Hour 3: CSS Flexbox for Components
## Guided Coding Exercises

### Exercise 3.1: Understanding Flexbox Basics (20 minutes)

**Objective:** Learn how Flexbox handles one-dimensional layouts.

**Step 1:** Make the card content flexible
\`\`\`css
.card__content {
    display: flex;
    flex-direction: column; /* Stack items vertically */
    padding: 1.5rem;
    background-color: white;
}
\`\`\`

**What you learned:**
- `display: flex` creates a flex container
- `flex-direction: column` stacks items vertically
- Default is `row` (horizontal)

**Step 2:** Add spacing between flex items
\`\`\`css
.card__content {
    display: flex;
    flex-direction: column;
    gap: 1rem; /* Space between all flex items */
    padding: 1.5rem;
    background-color: white;
}
\`\`\`

**What you learned:**
- `gap` works with flexbox too (modern browsers)
- Creates consistent spacing between items

**Step 3:** Make the description take available space
\`\`\`css
.card__content {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    padding: 1.5rem;
    background-color: white;
    height: 100%; /* Fill the card height */
}

.card__description {
    flex: 1; /* Take all available space */
}
\`\`\`

**Test it:** Cards with different text lengths now have buttons aligned at the bottom!

**What you learned:**
- `flex: 1` means "grow to fill available space"
- This pushes other items to the edges

### Exercise 3.2: Creating Flexible Buttons (25 minutes)

**Step 1:** Make buttons flexible containers
\`\`\`css
.btn {
    display: flex; /* Not inline-flex yet */
    align-items: center; /* Center content vertically */
    justify-content: center; /* Center content horizontally */
    gap: 0.5rem; /* Space between text and icon */
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 8px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-weight: 500;
    cursor: pointer;
}
\`\`\`

**What you learned:**
- `align-items: center` centers items on the cross-axis (vertical when row)
- `justify-content: center` centers items on the main axis (horizontal when row)

**Step 2:** Add icons to buttons
\`\`\`html
<!-- Update your button HTML -->
<button class="btn btn--primary" data-sketch="particle-system">
    View Sketch
    <svg class="btn__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path d="M7 17L17 7M17 7H7M17 7V17"></path>
    </svg>
</button>
\`\`\`

\`\`\`css
.btn__icon {
    width: 1rem;
    height: 1rem;
    transition: transform 0.2s ease;
}

.btn:hover .btn__icon {
    transform: translateX(2px); /* Move icon on hover */
}
\`\`\`

**What you learned:**
- SVG icons inherit the text color with `stroke="currentColor"`
- Flexbox automatically aligns the icon with the text

**Step 3:** Make buttons inline-flex for better layout
\`\`\`css
.btn {
    display: inline-flex; /* Only takes needed space */
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    /* ... rest of styles ... */
}
\`\`\`

**What you learned:**
- `inline-flex` behaves like `inline-block` but with flex properties
- Better for buttons that should only be as wide as their content

### Exercise 3.3: Flexible Modal Header (20 minutes)

**Step 1:** Create a flexible modal header
\`\`\`css
.modal__header {
    display: flex;
    align-items: center; /* Center items vertically */
    justify-content: space-between; /* Push items to opposite ends */
    padding: 1.5rem 2rem;
    border-bottom: 1px solid #e2e8f0;
    background: #f8fafc;
}
\`\`\`

**What you learned:**
- `justify-content: space-between` pushes items to opposite ends
- Perfect for headers with title on left, close button on right

**Step 2:** Style the close button with flexbox
\`\`\`css
.modal__close {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 2.5rem;
    height: 2.5rem;
    border: none;
    border-radius: 50%;
    background: transparent;
    color: #718096;
    cursor: pointer;
    transition: all 0.2s ease;
}

.modal__close:hover {
    background: #e2e8f0;
    color: #2d3748;
}
\`\`\`

**What you learned:**
- Flexbox centers the X icon perfectly in the circular button
- No need to calculate padding or margins

### Exercise 3.4: Responsive Flexbox Patterns (15 minutes)

**Step 1:** Create a flexible card preview area
\`\`\`css
.card__preview {
    position: relative;
    overflow: hidden;
    aspect-ratio: 3 / 2; /* Modern way to maintain aspect ratio */
}

.card__overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(0, 0, 0, 0.4);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.card:hover .card__overlay {
    opacity: 1;
}
\`\`\`

**What you learned:**
- `aspect-ratio` maintains proportions without padding tricks
- Flexbox centers the play icon perfectly over the image

**Step 2:** Make the entire card flexible
\`\`\`css
.card {
    display: flex;
    flex-direction: column;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}

.card__content {
    flex: 1; /* Take remaining space after image */
    display: flex;
    flex-direction: column;
    gap: 1rem;
    padding: 1.5rem;
}
\`\`\`

**What you learned:**
- Cards are now flexible containers
- Content area grows to fill available space
- All cards in a row will be the same height

### Hour 3 Challenge: Create a Navigation Bar

**Your Task:** Create a responsive navigation bar using flexbox with:
- Logo on the left
- Navigation links in the center
- User profile on the right
- Mobile-friendly collapse behavior

**Solution:**
\`\`\`html
<nav class="navbar">
    <div class="navbar__brand">
        <h1>Portfolio</h1>
    </div>
    <ul class="navbar__nav">
        <li><a href="#home">Home</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>
    <div class="navbar__user">
        <button class="btn btn--secondary">Login</button>
    </div>
</nav>
\`\`\`

\`\`\`css
.navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1rem 2rem;
    background: white;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.navbar__nav {
    display: flex;
    list-style: none;
    gap: 2rem;
    margin: 0;
    padding: 0;
}

.navbar__nav a {
    text-decoration: none;
    color: #2d3748;
    font-weight: 500;
    transition: color 0.2s ease;
}

.navbar__nav a:hover {
    color: #667eea;
}

/* Mobile responsive */
@media (max-width: 768px) {
    .navbar {
        flex-direction: column;
        gap: 1rem;
    }
    
    .navbar__nav {
        order: 3; /* Move nav to bottom */
        gap: 1rem;
    }
}
\`\`\`

### Flexbox vs Grid: When to Use Which?

**Use Flexbox for:**
- ✅ One-dimensional layouts (rows OR columns)
- ✅ Component-level layouts (buttons, cards, navigation)
- ✅ Centering content
- ✅ Distributing space between items
- ✅ Aligning items

**Use Grid for:**
- ✅ Two-dimensional layouts (rows AND columns)
- ✅ Page-level layouts
- ✅ Complex positioning
- ✅ Overlapping content
- ✅ Responsive design without media queries

### Common Flexbox Patterns

**1. Perfect Centering:**
\`\`\`css
.center-everything {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}
\`\`\`

**2. Sticky Footer:**
\`\`\`css
.page {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

.main-content {
    flex: 1; /* Takes all available space */
}
\`\`\`

**3. Equal Height Columns:**
\`\`\`css
.columns {
    display: flex;
    gap: 2rem;
}

.column {
    flex: 1; /* All columns equal width */
}
\`\`\`

### Key Takeaways from Hour 3:
- ✅ Flexbox excels at one-dimensional layouts
- ✅ `align-items` and `justify-content` control alignment
- ✅ `flex: 1` makes items grow to fill space
- ✅ `gap` provides consistent spacing
- ✅ Combine flexbox with grid for powerful layouts
- ✅ `inline-flex` is perfect for buttons and inline components
